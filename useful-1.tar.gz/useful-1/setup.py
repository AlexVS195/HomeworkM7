from setuptools import setup, find_namespace_packages

# setup(
#     name='clean-folder',
#     version='1.0.0',
#     author='Oleksandr Symashkin',
#     author_email='asemashk@ukr.net',
#     packages=find_namespace_packages(),
#     entry_points={'console_scripts': ['clean=clean-folder.clean:start']}
# )


setup(
    name='useful',
    version='1',
    description='Very useful code',
    url='http://github.com/dummy_user/useful',
    author='Flying Circus',
    author_email='flyingcircus@example.com',
    license='MIT',
    packages=find_namespace_packages(),
    install_requires=['markdown'],
)